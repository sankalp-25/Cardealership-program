#include<stdio.h>
#include<stdlib.h>
#include<windows.h>
int i,j;
int main_exit;
void menu();
char kvp[40];

struct user
{
    char name[30];
    char password[30];
    long int aadhar;
}t1;

void registration();
void login();


char fname[]={"mydatabase.txt"};

void registration()
{
    FILE *fp;
    struct user t1;
    int g;

    fp=fopen(fname,"a");

    printf("\n\n\t\t\tPLEASE ENTER THE FOLLOWING DETAILS TO REGISTER !!");

    printf("\n\nENTER USERNAME : ");
    scanf("%s",t1.name);

    printf("\n\nENTER PASSWORD : ");
    scanf("%s",t1.password);

    printf("\n\nENTER AADHAR NUMBER : ");
    scanf("%ld", &t1.aadhar);

    fwrite(&t1,sizeof(t1),1,fp);

    fclose(fp);

    printf("\n\n\t\t\tYou have successfully registered");

    priyu:
    printf("\n\t\t\tIf you want to login give 1\n\t\t\tIf you want to exit press 0\n\t\t\t: ");
    scanf("%d",&g);
    if(g==1)
    {
    	login();
    }
    else if(g==0)
    	close();
    else
    {	printf("\n\t\t\tInvalid input please enter again : ");
		goto priyu;
    }
}

void login()
{
    FILE *fp;
    struct user t1;
    char uname[20],pass[20];
    int found=0,i;
    sri:
    
    printf("\n\n\t\t\tENTER YOUR LOGIN CREDENTIALS !!");
    fp=fopen(fname,"rb");

    printf("\n\n\n ENTER USERNAME: ");
    scanf("%s",kvp);

    printf("\nENTER PASSWORD  :");
    scanf("%s",pass);



    while(1)
    {
        fread(&t1,sizeof(t1),1,fp);

        if(feof(fp))
        {
            break;
        }
        if((strcmp(t1.name,kvp)==0) && (strcmp(t1.password,pass)==0))
        {

                found=1;
                printf("\n\n\n========================================================\n\n");
                printf("\n\n\t\t\tYou have logged in succesfully\n\n");
                printf("\n\n\n");

                menu();
        }
    }
    if(found==0)
    {
        do{
		printf("\n\n\t\t\tIncorrect login details\n\t\t\tIf you want to try again give 1\n\t\t\tIf you want to exit press 0");
		scanf("%d",&i);
		if(i==0)
			close();
		else if(i==1)
			goto sri;
	    }while(!(i==1 || i==0));
    }
    fclose(fp);

    exit(0);
}
void return_car()
{
    FILE *ptr,*srh,*sri;
    int t,rate,temp=1;
    int choice;
    float time;
    float intrst;
	FILE *tempFile;
	char ch;
	char abc[]="cars_lending1.txt";
	char xyz[]="cars_lending.txt";
	char pqr[]="cars_for_rent.txt";
	sri=fopen(pqr,"a");	
	ptr=fopen(abc,"a+"); 
	
    char s;
    while(!feof(ptr))
	{
		s= fgetc(ptr);
    printf("%c",s);
	}
	rewind(ptr);
	printf("\n\n\t\t\tEnter the car number to return or 0 to go back to main menu :  ");
	scanf("%d",&t);
	tempFile=fopen("cars_lending.txt","w");
	
	if(t==0)
	{
		fclose(tempFile);
		fclose(sri);
		fclose(ptr);
		menu();
	}
	
	else
	{	char rented_car[50];
		int i = 0;
		while (ch != EOF)
        {
        ch = getc(ptr);
        if (ch == '\n')
            temp++;
          
        if (temp != t)
        {
			putc(ch, tempFile);
        }
		else
		{
			putc(ch, sri);
		}
		if(temp == t)
		{
			
			rented_car[i] = ch;
			i++;
		}
			
			
			
        }
		rented_car[i] = '\0';
		rewind(tempFile);
		fseek(sri, 0, 2);
		
		printf("\n\n\t\t\tThank you for lending our car, you will be charged accordingly\n\t\t\thave a nice day");
		
		
	}
	fclose(tempFile);
	fclose(sri);
    fclose(ptr);
	remove(abc);
	rename(xyz,abc);
	if(t==0)
		menu();
	
	else
	{
		printf("\n\t\t\tEnter 1 to go to the main menu and 0 to exit:");
		scanf("%d",&t);
			if(t==1)
			{
				system("cls");
				menu();
			}
			else
			{
			system("cls"); 
			close();
			}
	}
}

void leasing()
{   
	FILE *ptr,*srh,*sri;
    int t,rate,temp=1;
    int choice;
    float time;
    float intrst;
	FILE *tempFile;
	char ch;
	char abc[]="cars_for_rent.txt";
	char xyz[]="cars_lending.txt";
	char pqr[]="cars_lending1.txt";
	sri=fopen(pqr,"a");	
	ptr=fopen(abc,"a+"); 
	
    char s;
    
    while(!feof(ptr))
	{
		s = fgetc(ptr);
    printf("%c",s);
	}
	rewind(ptr);
	printf("\n\nEnter the car number to lend or 0 to go back to main menu :  ");
	scanf("%d",&t);
	system("cls");
	tempFile=fopen("cars_lending.txt","w");
	
	if(t==0)
	{
		fclose(tempFile);
		fclose(sri);
		fclose(ptr);
		menu();
	}
	
	else
	{	
		t+=3;
	    ch = getc(ptr);
		while (ch != EOF)
        {
        ch = getc(ptr);
        if (ch == '\n')
            temp++;
          
            if (temp != t)
            {
				putc(ch, tempFile);
            }
			else
			{
				putc(ch, sri);
			}
			
        }
		fprintf(sri,"%s",t1.name);
		rewind(tempFile);
		printf("\n\n\t\t\tThank you for lending our car\n\t\t\thave a nice day");
		
		
	}
	fclose(tempFile);
	fclose(sri);
    fclose(ptr);           
	remove(abc);
    rename(xyz,abc); 
	if(t==0)
		menu();
	
	else
	{
		printf("\n\n\t\t\tEnter 1 to go to the main menu and 0 to exit:");
		scanf("%d",&main_exit);
			if (main_exit==1)
			{
				system("cls");
				menu();
			}
			else
			{
			system("cls"); 
			close();
			}
	}
}
void _2ndhand()
{
    FILE *sri,*our,*srh;
	float k;
	int i;
	char h,s;
	char xyz[]="damage.txt";
	san:
	printf("\n\nPlease tell us MRP of your car : ");
	scanf("%f",&k);
	k=k*(0.8);
	our=fopen(xyz,"r");
	printf("\n\n");
	while((s=fgetc(our))!=EOF)
	{
    printf("%c",s);
	}
	printf("\n\n");
	do{
		printf("\nPlease select appropriate damage percentage\nIf you want give your MRP again, give 9\nIf you want to go to main menu, give 0\n\n");
		scanf("%d",&i);
		if(i==9 || i==0)
			break;
		else if(i<0 || i>5)
		{
			printf("\n\nPlease select valid input\1\n");
		}
	}while(i<0 || i>5);
	if(i==9)
			goto san;
	else if(i==0)
		{
			menu();
		}
	switch(i)
	{
		
	 
        case 1:
        break;
        case 2:k=k*(0.85);
        break;
        case 3:k=k*(0.75);
        break;
		case 4:k=k*(0.65);
        break;
        default:
			printf("Sorry, you can't sell your car here!!");menu();break;
	}
	printf("We are offering %0.2f to your car\1\1",k);
	printf("\n\nIf you want to sell your car give 1\nIf not press anyother key : ");
	scanf(" %c",&h);
	if(h=='1')
	{
		printf("\n\n\xB2\xB2\xB2\xB2\xB2\xB2\xB2Thank you for selling your car, have a nice day\xB2\xB2\xB2\xB2\xB2\xB2\xB2\n\n");
		srh=fopen("sell_record.txt","a");
		fprintf(srh," %s has sold car at %f \n",kvp,k);
		fclose(srh);
		
	}
	else
	{
		menu();
		
	}
	
	}


void see(void)
{
    FILE *ptr,*cs1,*sri;
    int t,rate,temp=1;
    int choice;
    float time;
    float intrst;
	FILE *tempFile;
	char ch;
	char abc[]="cars.txt";
	char xyz[]="cars_sold.txt";
	char pqr[]="cars_sold1.txt";
	sri=fopen(pqr,"a");	
	ptr=fopen(abc,"r"); 
    char s;
    while((s=fgetc(ptr))!=EOF)
	{
    printf("%c",s);
	}
	rewind(ptr);
	printf("\n\nEnter the car number to buy or 0 to go back to main menu :  ");
	scanf("%d",&t);
	system("cls");
	tempFile=fopen("cars_sold.txt","w");
	
	if(t==0)
	{
		system("cls"); 
		close();
	}
	
	else
	{	
		t+=3;
	    ch = getc(ptr);
		while (ch != EOF)
        {
        ch = getc(ptr);
        if (ch == '\n')
            temp++;
          
            if (temp != t)
            {
				putc(ch, tempFile);
            }
			else
			{
				putc(ch, sri);
			}
			
        }
		rewind(tempFile);
		printf("Thank you for buying car, have a nice day \1");
		
		
	}
	fclose(tempFile);
	fclose(sri);
    fclose(ptr);           
	remove(abc);
    rename(xyz,abc); 
	if(t==0)
		menu();
	
	else
	{
		printf("\nEnter 1 to go to the main menu and 0 to exit:");
		scanf("%d",&main_exit);
			if (main_exit==1)
			{
				system("cls");
				menu();
			}
			else
			{
			system("cls"); 
			close();
			}
	}
}

void close(void)
{
    printf("\n\n\n\n");
}


void menu(void)
{   int choice;
    do{
		system("cls");
		printf("\n\n\t\t\tCAR DEALERSHIP SYSTEM");
		printf("\n\n\n\t\t\t\xB2\xB2\xB2\xB2\xB2\xB2\xB2 WELCOME TO THE MAIN MENU \xB2\xB2\xB2\xB2\xB2\xB2\xB2");
		printf("\n\t\t1. To see the list of used cars \n\t\t2. TO sell your car \n\t\t3. Leasing cars details\n\t\t4. If you want to return your car\n\t\t5. Exit\n\n\n\n\n\t\t Enter your choice : ");
		scanf("%d",&choice);
		if(sizeof(choice)!= sizeof(int) || (choice<0 && choice>5))
			printf("\n\nEnter a valid choice");
		
	}while(sizeof(choice)!= sizeof(int) || (choice<0 && choice>5));

    system("cls");
    switch(choice)
    {
        case 1:see();
        break;
        case 2:_2ndhand();
        break;
        case 3:leasing();
        break;
        case 4:return_car();
        break;
		case 5:close();
        break;

    }
}
int main()
{	
	//leasing();
	printf("Give 1 for logging in\nGive 2 for register : ");//char pass[10],password[10]="ss";
    int i;
    do
	{
		scanf("%d",&i);
		if(i==1)
		{
			login();
		}
		else if(i==2)
		{
			registration();
		}
		else
		{
			printf("\n\n\t\tPlease enter again\n\n");
		}
	}while(!(i==1 || i==2));
	return 0;
}
